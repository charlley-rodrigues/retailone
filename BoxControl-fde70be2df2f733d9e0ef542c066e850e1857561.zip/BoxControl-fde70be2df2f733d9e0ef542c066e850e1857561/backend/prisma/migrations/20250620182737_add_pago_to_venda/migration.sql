-- AlterTable
ALTER TABLE "Venda" ADD COLUMN     "pago" BOOLEAN NOT NULL DEFAULT true;
